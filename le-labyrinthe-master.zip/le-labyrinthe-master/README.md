		---	PROJET LE LABYRINTHE	---

Auteurs :

	- Théo Gayant

	- Olivier Buhendwa

	- Nguyen Viet

	- Martin Springett

	- Mehdi Sabiri

#############################################################################
Executer le programme :
 
	- Soit avec le .jar --> $ ./runfx build --> Sert a crée le .jar
						  --> $ ./runfx run --> Executer le programme
	
	- Soit via eclipse -> on va dans la classe main et on l'éxécute

Guide d'utilisation :

	- Le plateau du jeu sur la gauche, avec les flèches d'insertions de la carte en jaune. Quand on clique sur une flèche jaune cela insère la carte à placer, limité à un ajout par tour et par joueur
	- La carte à placer se situe en haut à droite, on peut la faire pivoter grâce au bouton situer juste en dessous
	- Le bouton suivant permet de passer au tour suivant
	- Le tableau des objectifs de chaque joueurs se situe à droite au milieu, il permet d'indiquer à chaque joueur le trésor qu'il doit trouvé
	- Le pad, se situe en bas à droite, on y voit le joueur actif, et lors du clique sur les flèches cela permet de déplacer le joueur dans la direction choisit si cela est possible

	+ Le joueur doit obligatoirement poser la carte avant de pouvoir se déplacer ou bien passer son tour
	+ Si le joueur passe sur son trésor, il est alors stopé et on passe au tour suivant
	+ Si le joueur sort du terrain il est téléporté à son spawn ou bien à l'opposé

############################################################################

Fonctionnalité implémenté (pour chaque personne) :

-Théo Gayant :

	- Toute la classe Cartes_laby.java --> Gestion d'une carte labyrinthes / Sens / Forme / Tourner la carte / Changer sa position / Gerer et obtenir les chemins ouvert selon le sens et la forme de la carte
	- Toute la classe Jeu.java --> Gestion du jeu / Initialisation du plateau de jeu / Mélange des cartes à placer, des trésors / Distribution des trésors aux joueurs et sur les cartes / Gérer l'insertion d'une carte par le joueur sur le plateau, décalage de la ligne/colonne de carte / Retour a la case départ ou opposé si le joueur sort du plateau / Gestion du tour des joueurs / Vérification avant de pouvoir se déplacer, il faut que le joueur ai placé la carte avant de pouvoir se déplacer / Vérification si le joueur est sur son trésor...
	- Toute la classe MyViewController.java (= au controller du jeu) --> Gestion du controller du jeu via la vue, si le joueur clique sur un certain bouton on fait telle action
	- La classe Sens.java et Forme.java --> Enum qui permet de différencier le sens et a la forme des cartes.
	- Quelques méthode de la classe Joueur.java
	- la classe MainGame
	- L'intégralité de la partie Vue (sauf le menu) --> création de la vue grâce à scene builder, plateau de jeu, les boutons, labels etc..
	- Un peu de documentation (juste sur les classes et méthodes que j'ai crée)

-Olivier Buhendwa :

	- Toute la classe Joueur (avec Théo) --> Récuperer le nom de la carte trésor à trouver / Vérification si un ou tous le(s) trésor(s) est(sont trouvé(s) / Ajout de d'une carte trésor dans la pile des cartes du joueur / Deplacer pour le déplacement du joueur / Vérification si le joueur a terminé de jouer.

	- Toute la classe IA --> Initialisation d'une matrice boolean 'dejaVu' qui servira à marquer les cases visitées par l'IA / casePlusProche : pour aller à la case la plus proche du trésor recherché en calculant la distance minimum / CoordTresor : pour récuperer les coordonnées du trésor recherché / distance : pour calculer la distance entre deux points / getCasesVoisines : pour vérifier si les cases voisines sont accessibles par un chemin / prochaineDirection : Marque à true tous les chemins possibles pour atteindre le trésor recherché, si on trouve le trésor, on retire la carte laby de la pile de l'IA / go : pour gérer toutes les actions de l'IA entre autre le deplacement pour aller trouver les tresors, rentrer à la case départ si tous les tresors sont trouvés.

-Nguyen Viet :

	- Toute la classe ListeTresor.java
	- Découpage des images trésors
	- Diagramme UML

-Martin Springett :

	- Toute la partie graphique menu
	- Toute la documentation (classes et packages)
	- Quelques modifications des méthodes dans le modèle
	- La classe Main que j'ai renommé en MainGame(lancement du jeu)
	- La classe Main que j'ai créé laissant place au menu principal
	- Le fichier FXML du menu principal

-Mehdi Sabiri :

Fonctionnalité non-implémenté :

	- Trésor vivant (on a juste créer l'attribut estVivant)
	- Les thèmes (BONUS)
	- L'IA non-implémenté (Olivier a commencer a l'a réaliser mais pas terminer)
	- Variante avec les bonus/malus lorsqu’un trésor arrive sur la case où un joueur a son pion (BONUS)

############################################################################

 ![Alt text](./diagramme_classe.png?raw=true "Title")
