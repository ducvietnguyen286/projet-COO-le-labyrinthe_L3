package fr.li3.coo.projet;

/**
 * Enumération des différents sens d'une carte.
 * @author Duc Viet NGUYEN
 */

public enum Sens {
	HAUT, GAUCHE, DROITE, BAS
}
