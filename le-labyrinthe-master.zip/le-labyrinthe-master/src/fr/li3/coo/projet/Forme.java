package fr.li3.coo.projet;

/**
 * Enumeration permettant de lister les differentes formes.
 * @author Martin Springett
 */

public enum Forme {
	DROIT, EN_T, ANGLE_D
}
