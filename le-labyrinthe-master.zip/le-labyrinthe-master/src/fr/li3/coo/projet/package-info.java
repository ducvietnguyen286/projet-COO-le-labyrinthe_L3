/**
 * Package principal du projet. Toutes les fonctionnalités et classes du projet sont dans ce package.
 */

package fr.li3.coo.projet;