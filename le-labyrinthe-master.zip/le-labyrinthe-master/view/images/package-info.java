/**
 * Package contenant les images du projet.
 */

package images;