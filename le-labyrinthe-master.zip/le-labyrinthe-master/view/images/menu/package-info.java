/**
 * @author Martin Springett
 * Package accueillant les ressources du menu
 */

package images.menu;
