/**
 * Package Contenant les images des trésors du projet.
 */

package images.tresors;